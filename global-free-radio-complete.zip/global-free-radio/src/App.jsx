import { useState, useEffect } from 'react'
import Header from './components/Header'
import StationCard from './components/StationCard'
import Player from './components/Player'
import TopStations from './components/TopStations'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, Globe, Music, Star } from 'lucide-react'
import './App.css'

function App() {
  const [stations, setStations] = useState([])
  const [loading, setLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCountry, setSelectedCountry] = useState(null)
  const [selectedGenre, setSelectedGenre] = useState(null)
  const [currentStation, setCurrentStation] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [favorites, setFavorites] = useState([])
  const [featuredStations, setFeaturedStations] = useState([])
  const [showTop10, setShowTop10] = useState(false)

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('radio-favorites')
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites))
    }
  }, [])

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem('radio-favorites', JSON.stringify(favorites))
  }, [favorites])

  // Load featured stations on mount
  useEffect(() => {
    if (!searchQuery && !selectedCountry && !selectedGenre && !showTop10) {
      loadFeaturedStations()
    }
  }, [searchQuery, selectedCountry, selectedGenre, showTop10])

  // Search when filters change
  useEffect(() => {
    if (selectedCountry || selectedGenre) {
      searchWithFilters()
    }
  }, [selectedCountry, selectedGenre])

  const loadFeaturedStations = async () => {
    setLoading(true)
    try {
      const response = await fetch('https://de1.api.radio-browser.info/json/stations/topclick/10')
      const data = await response.json()
      setFeaturedStations(data)
    } catch (error) {
      console.error('Error loading featured stations:', error)
    } finally {
      setLoading(false)
    }
  }

  const searchStations = async (query) => {
    if (!query.trim() && !selectedCountry && !selectedGenre) {
      setStations([])
      setShowTop10(false)
      return
    }

    setLoading(true)
    setShowTop10(false)
    try {
      let url = 'https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&limit=20'
      
      if (query.trim()) {
        url += `&name=${encodeURIComponent(query)}`
      }
      
      if (selectedCountry) {
        url += `&countrycode=${selectedCountry}`
      }
      
      if (selectedGenre) {
        url += `&tag=${encodeURIComponent(selectedGenre)}`
      }
      
      const response = await fetch(url)
      const data = await response.json()
      setStations(data)
    } catch (error) {
      console.error('Error searching stations:', error)
    } finally {
      setLoading(false)
    }
  }

  const searchWithFilters = async () => {
    if (!selectedCountry && !selectedGenre) {
      setStations([])
      return
    }

    setLoading(true)
    setShowTop10(false)
    try {
      let url = 'https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&limit=20'
      
      if (selectedCountry) {
        url += `&countrycode=${selectedCountry}`
      }
      
      if (selectedGenre) {
        url += `&tag=${encodeURIComponent(selectedGenre)}`
      }
      
      const response = await fetch(url)
      const data = await response.json()
      setStations(data)
    } catch (error) {
      console.error('Error searching with filters:', error)
    } finally {
      setLoading(false)
    }
  }

  const handlePlay = (station) => {
    setCurrentStation(station)
    setIsPlaying(true)
  }

  const handlePause = () => {
    setIsPlaying(false)
  }

  const toggleFavorite = (station) => {
    setFavorites(prev => {
      const exists = prev.find(fav => fav.stationuuid === station.stationuuid)
      if (exists) {
        return prev.filter(fav => fav.stationuuid !== station.stationuuid)
      } else {
        return [...prev, station]
      }
    })
  }

  const isFavorite = (station) => {
    return favorites.some(fav => fav.stationuuid === station.stationuuid)
  }

  const isCurrentlyPlaying = (station) => {
    return currentStation?.stationuuid === station.stationuuid && isPlaying
  }

  const handleCountrySelect = (countryCode) => {
    setSelectedCountry(countryCode)
    setSearchQuery('')
    setShowTop10(false)
  }

  const handleGenreSelect = (genre) => {
    setSelectedGenre(genre)
    setSearchQuery('')
    setShowTop10(false)
  }

  const handleShowTop10 = () => {
    setShowTop10(true)
    setSearchQuery('')
    setSelectedCountry(null)
    setSelectedGenre(null)
    setStations([])
  }

  const isFiltered = searchQuery || selectedCountry || selectedGenre || showTop10

  return (
    <div className="min-h-screen bg-background">
      <Header 
        onSearch={searchStations}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onCountrySelect={handleCountrySelect}
        selectedCountry={selectedCountry}
        onGenreSelect={handleGenreSelect}
        selectedGenre={selectedGenre}
        onShowTop10={handleShowTop10}
      />

      <main className="container mx-auto px-4 py-8 pb-32">
        {/* Hero Section */}
        {!isFiltered && (
          <section className="text-center mb-12">
            <div className="relative">
              <h1 className="text-4xl md:text-6xl font-bold mb-4 neon-text gradient-bg bg-clip-text text-transparent">
                Global Free Radio
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Descubra estações de rádio online gratuitas de todo o mundo
              </p>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
                <Card className="glass-effect">
                  <CardContent className="p-4 text-center">
                    <Globe className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <div className="text-2xl font-bold">195+</div>
                    <div className="text-sm text-muted-foreground">Países</div>
                  </CardContent>
                </Card>
                <Card className="glass-effect">
                  <CardContent className="p-4 text-center">
                    <Music className="h-8 w-8 mx-auto mb-2 text-secondary" />
                    <div className="text-2xl font-bold">50K+</div>
                    <div className="text-sm text-muted-foreground">Estações</div>
                  </CardContent>
                </Card>
                <Card className="glass-effect">
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="h-8 w-8 mx-auto mb-2 text-accent" />
                    <div className="text-2xl font-bold">24/7</div>
                    <div className="text-sm text-muted-foreground">Online</div>
                  </CardContent>
                </Card>
                <Card className="glass-effect">
                  <CardContent className="p-4 text-center">
                    <Star className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
                    <div className="text-2xl font-bold">100%</div>
                    <div className="text-sm text-muted-foreground">Gratuito</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        )}

        {/* Quick Filters */}
        {!isFiltered && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Explorar por Categoria</h2>
            <div className="flex flex-wrap gap-2">
              {['Pop', 'Rock', 'Jazz', 'Electronic', 'Classical', 'News', 'Talk', 'Country'].map((genre) => (
                <Button
                  key={genre}
                  variant="outline"
                  onClick={() => {
                    setSelectedGenre(genre.toLowerCase())
                    setSearchQuery('')
                    setShowTop10(false)
                  }}
                  className="hover:retro-glow"
                >
                  {genre}
                </Button>
              ))}
            </div>
          </section>
        )}

        {/* Top 10 Stations */}
        {showTop10 && (
          <section className="mb-8">
            <TopStations
              onPlay={handlePlay}
              onPause={handlePause}
              currentStation={currentStation}
              isPlaying={isPlaying}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
            />
          </section>
        )}

        {/* Featured Stations */}
        {!isFiltered && featuredStations.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <TrendingUp className="h-6 w-6 mr-2 text-accent" />
              Estações em Destaque
            </h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {featuredStations.slice(0, 6).map((station) => (
                <StationCard
                  key={station.stationuuid}
                  station={station}
                  isPlaying={isCurrentlyPlaying(station)}
                  onPlay={handlePlay}
                  onPause={handlePause}
                  isFavorite={isFavorite(station)}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </section>
        )}

        {/* Search/Filter Results */}
        {(searchQuery || selectedCountry || selectedGenre) && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">
                {searchQuery ? `Resultados para "${searchQuery}"` : 'Estações Filtradas'}
                {selectedCountry && (
                  <span className="text-lg ml-2">🌍 {selectedCountry}</span>
                )}
                {selectedGenre && (
                  <span className="text-lg ml-2">🎵 {selectedGenre}</span>
                )}
              </h2>
              <Badge variant="secondary">
                {stations.length} estações encontradas
              </Badge>
            </div>
            
            {loading ? (
              <div className="text-center py-12">
                <div className="inline-flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  <span>Buscando estações...</span>
                </div>
              </div>
            ) : stations.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {stations.map((station) => (
                  <StationCard
                    key={station.stationuuid}
                    station={station}
                    isPlaying={isCurrentlyPlaying(station)}
                    onPlay={handlePlay}
                    onPause={handlePause}
                    isFavorite={isFavorite(station)}
                    onToggleFavorite={toggleFavorite}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  Nenhuma estação encontrada. Tente uma busca diferente.
                </p>
              </div>
            )}
          </section>
        )}

        {/* Favorites Section */}
        {!isFiltered && favorites.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Star className="h-6 w-6 mr-2 text-yellow-500" />
              Suas Favoritas
            </h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {favorites.slice(0, 6).map((station) => (
                <StationCard
                  key={station.stationuuid}
                  station={station}
                  isPlaying={isCurrentlyPlaying(station)}
                  onPlay={handlePlay}
                  onPause={handlePause}
                  isFavorite={true}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Player */}
      <Player
        currentStation={currentStation}
        isPlaying={isPlaying}
        onPlay={handlePlay}
        onPause={handlePause}
        isFavorite={currentStation ? isFavorite(currentStation) : false}
        onToggleFavorite={toggleFavorite}
      />
    </div>
  )
}

export default App
