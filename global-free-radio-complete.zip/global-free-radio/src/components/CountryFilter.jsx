import { useState, useEffect } from 'react'
import { Globe, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'

const CountryFilter = ({ onCountrySelect, selectedCountry }) => {
  const [countries, setCountries] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadCountries()
  }, [])

  const loadCountries = async () => {
    setLoading(true)
    try {
      const response = await fetch('https://de1.api.radio-browser.info/json/countries')
      const data = await response.json()
      // Sort by station count and take top 50
      const sortedCountries = data
        .filter(country => country.stationcount > 0)
        .sort((a, b) => b.stationcount - a.stationcount)
        .slice(0, 50)
      setCountries(sortedCountries)
    } catch (error) {
      console.error('Error loading countries:', error)
    } finally {
      setLoading(false)
    }
  }

  const getFlagEmoji = (countryCode) => {
    if (!countryCode || countryCode.length !== 2) return '🌍'
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt())
    return String.fromCodePoint(...codePoints)
  }

  const getSelectedCountryName = () => {
    if (!selectedCountry) return 'Todos os Países'
    const country = countries.find(c => c.iso_3166_1 === selectedCountry)
    return country ? country.name : selectedCountry
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center space-x-2">
          <Globe className="h-4 w-4" />
          <span>{getSelectedCountryName()}</span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 max-h-96 overflow-y-auto">
        <DropdownMenuItem onClick={() => onCountrySelect(null)}>
          <div className="flex items-center space-x-2">
            <span className="text-lg">🌍</span>
            <div>
              <div className="font-medium">Todos os Países</div>
              <div className="text-xs text-muted-foreground">Mostrar todas as estações</div>
            </div>
          </div>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        {loading ? (
          <DropdownMenuItem disabled>
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span>Carregando países...</span>
            </div>
          </DropdownMenuItem>
        ) : (
          countries.map((country) => (
            <DropdownMenuItem
              key={country.iso_3166_1}
              onClick={() => onCountrySelect(country.iso_3166_1)}
            >
              <div className="flex items-center space-x-2 w-full">
                <span className="text-lg">{getFlagEmoji(country.iso_3166_1)}</span>
                <div className="flex-1">
                  <div className="font-medium">{country.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {country.stationcount} estações
                  </div>
                </div>
              </div>
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export default CountryFilter

