import { useState } from 'react'
import { Star, Trash2, Play, Pause, Edit3, Save, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import DraggableStationCard from './DraggableStationCard'
import { DragDropProvider } from './DragDropProvider'
import { useTranslation } from '../hooks/useTranslation'

const FavoritesManager = ({ 
  favorites, 
  onReorderFavorites, 
  onRemoveFavorite, 
  onPlay, 
  onPause, 
  currentStation, 
  isPlaying,
  isOpen,
  onClose
}) => {
  const { t } = useTranslation()
  const [editingPlaylist, setEditingPlaylist] = useState(null)
  const [playlistName, setPlaylistName] = useState('')
  const [playlists, setPlaylists] = useState(() => {
    const saved = localStorage.getItem('radio-playlists')
    return saved ? JSON.parse(saved) : []
  })

  const handleReorder = (draggedStation, targetStation) => {
    const draggedIndex = favorites.findIndex(fav => fav.stationuuid === draggedStation.item.stationuuid)
    const targetIndex = favorites.findIndex(fav => fav.stationuuid === targetStation.stationuuid)
    
    if (draggedIndex === -1 || targetIndex === -1) return
    
    const newFavorites = [...favorites]
    const [removed] = newFavorites.splice(draggedIndex, 1)
    newFavorites.splice(targetIndex, 0, removed)
    
    onReorderFavorites(newFavorites)
  }

  const createPlaylist = () => {
    if (!playlistName.trim()) return
    
    const newPlaylist = {
      id: Date.now().toString(),
      name: playlistName,
      stations: [...favorites],
      createdAt: new Date().toISOString()
    }
    
    const updatedPlaylists = [...playlists, newPlaylist]
    setPlaylists(updatedPlaylists)
    localStorage.setItem('radio-playlists', JSON.stringify(updatedPlaylists))
    setPlaylistName('')
  }

  const deletePlaylist = (playlistId) => {
    const updatedPlaylists = playlists.filter(p => p.id !== playlistId)
    setPlaylists(updatedPlaylists)
    localStorage.setItem('radio-playlists', JSON.stringify(updatedPlaylists))
  }

  const loadPlaylist = (playlist) => {
    // This would need to be implemented in the parent component
    console.log('Loading playlist:', playlist)
  }

  const isCurrentlyPlaying = (station) => {
    return currentStation?.stationuuid === station.stationuuid && isPlaying
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto glass-effect">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Star className="h-5 w-5 text-yellow-500" />
            <span>Gerenciar Favoritos</span>
            <Badge variant="secondary">{favorites.length} estações</Badge>
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Create Playlist */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Criar Playlist</h3>
            <div className="flex space-x-2">
              <Input
                placeholder="Nome da playlist..."
                value={playlistName}
                onChange={(e) => setPlaylistName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && createPlaylist()}
              />
              <Button onClick={createPlaylist} disabled={!playlistName.trim()}>
                <Save className="h-4 w-4 mr-2" />
                Salvar
              </Button>
            </div>
          </div>

          {/* Existing Playlists */}
          {playlists.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Playlists Salvas</h3>
              <div className="grid gap-3">
                {playlists.map((playlist) => (
                  <Card key={playlist.id} className="glass-effect">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{playlist.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {playlist.stations.length} estações • {new Date(playlist.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => loadPlaylist(playlist)}
                          >
                            <Play className="h-4 w-4 mr-1" />
                            Carregar
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deletePlaylist(playlist.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Draggable Favorites List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Suas Estações Favoritas</h3>
              <p className="text-sm text-muted-foreground">
                Arraste para reordenar
              </p>
            </div>
            
            {favorites.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Star className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhuma estação favorita ainda.</p>
                <p className="text-sm">Clique no coração ♥ nas estações para adicioná-las aos favoritos.</p>
              </div>
            ) : (
              <DragDropProvider>
                <div className="space-y-3">
                  {favorites.map((station, index) => (
                    <div key={station.stationuuid} className="relative group">
                      <DraggableStationCard
                        station={station}
                        isPlaying={isCurrentlyPlaying(station)}
                        onPlay={onPlay}
                        onPause={onPause}
                        isFavorite={true}
                        onToggleFavorite={onRemoveFavorite}
                        isDraggable={true}
                        onReorder={handleReorder}
                      />
                      
                      {/* Position indicator */}
                      <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-primary rounded-full flex items-center justify-center text-xs font-bold text-white">
                        {index + 1}
                      </div>
                      
                      {/* Remove button */}
                      <Button
                        variant="outline"
                        size="icon"
                        className="absolute -right-2 -top-2 opacity-0 group-hover:opacity-100 transition-opacity bg-destructive hover:bg-destructive/80 text-white border-destructive"
                        onClick={() => onRemoveFavorite(station)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </DragDropProvider>
            )}
          </div>

          {/* Quick Actions */}
          {favorites.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
              <Button
                variant="outline"
                onClick={() => {
                  // Shuffle favorites
                  const shuffled = [...favorites].sort(() => Math.random() - 0.5)
                  onReorderFavorites(shuffled)
                }}
              >
                🔀 Embaralhar
              </Button>
              
              <Button
                variant="outline"
                onClick={() => {
                  // Sort by name
                  const sorted = [...favorites].sort((a, b) => a.name.localeCompare(b.name))
                  onReorderFavorites(sorted)
                }}
              >
                🔤 Ordenar A-Z
              </Button>
              
              <Button
                variant="outline"
                onClick={() => {
                  // Sort by country
                  const sorted = [...favorites].sort((a, b) => (a.country || '').localeCompare(b.country || ''))
                  onReorderFavorites(sorted)
                }}
              >
                🌍 Ordenar por País
              </Button>
              
              <Button
                variant="outline"
                onClick={() => {
                  // Clear all favorites
                  if (confirm('Tem certeza que deseja remover todas as estações favoritas?')) {
                    favorites.forEach(station => onRemoveFavorite(station))
                  }
                }}
              >
                🗑️ Limpar Tudo
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default FavoritesManager

