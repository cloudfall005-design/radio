import { useState, useEffect } from 'react'
import { Music, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'

const GenreFilter = ({ onGenreSelect, selectedGenre }) => {
  const [genres, setGenres] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadGenres()
  }, [])

  const loadGenres = async () => {
    setLoading(true)
    try {
      const response = await fetch('https://de1.api.radio-browser.info/json/tags')
      const data = await response.json()
      // Sort by station count and take top 50
      const sortedGenres = data
        .filter(genre => genre.stationcount > 10) // Only genres with more than 10 stations
        .sort((a, b) => b.stationcount - a.stationcount)
        .slice(0, 50)
      setGenres(sortedGenres)
    } catch (error) {
      console.error('Error loading genres:', error)
    } finally {
      setLoading(false)
    }
  }

  const getGenreIcon = (genreName) => {
    const genre = genreName.toLowerCase()
    if (genre.includes('rock')) return '🎸'
    if (genre.includes('jazz')) return '🎷'
    if (genre.includes('classical')) return '🎼'
    if (genre.includes('electronic') || genre.includes('techno') || genre.includes('house')) return '🎧'
    if (genre.includes('pop')) return '🎤'
    if (genre.includes('country')) return '🤠'
    if (genre.includes('hip hop') || genre.includes('rap')) return '🎤'
    if (genre.includes('folk')) return '🪕'
    if (genre.includes('blues')) return '🎺'
    if (genre.includes('reggae')) return '🏝️'
    if (genre.includes('metal')) return '⚡'
    if (genre.includes('news')) return '📰'
    if (genre.includes('talk')) return '🎙️'
    if (genre.includes('sport')) return '⚽'
    if (genre.includes('christian') || genre.includes('gospel')) return '⛪'
    return '🎵'
  }

  const getSelectedGenreName = () => {
    if (!selectedGenre) return 'Todos os Gêneros'
    const genre = genres.find(g => g.name === selectedGenre)
    return genre ? genre.name : selectedGenre
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center space-x-2">
          <Music className="h-4 w-4" />
          <span>{getSelectedGenreName()}</span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 max-h-96 overflow-y-auto">
        <DropdownMenuItem onClick={() => onGenreSelect(null)}>
          <div className="flex items-center space-x-2">
            <span className="text-lg">🎵</span>
            <div>
              <div className="font-medium">Todos os Gêneros</div>
              <div className="text-xs text-muted-foreground">Mostrar todas as estações</div>
            </div>
          </div>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        {loading ? (
          <DropdownMenuItem disabled>
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span>Carregando gêneros...</span>
            </div>
          </DropdownMenuItem>
        ) : (
          genres.map((genre) => (
            <DropdownMenuItem
              key={genre.name}
              onClick={() => onGenreSelect(genre.name)}
            >
              <div className="flex items-center space-x-2 w-full">
                <span className="text-lg">{getGenreIcon(genre.name)}</span>
                <div className="flex-1">
                  <div className="font-medium capitalize">{genre.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {genre.stationcount} estações
                  </div>
                </div>
              </div>
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export default GenreFilter

