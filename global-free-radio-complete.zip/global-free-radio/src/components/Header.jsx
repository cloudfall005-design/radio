import { useState } from 'react'
import { Search, Radio, Menu, X, Settings, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import CountryFilter from './CountryFilter'
import GenreFilter from './GenreFilter'
import LanguageSelector from './LanguageSelector'
import { useTranslation } from '../hooks/useTranslation'

const Header = ({ 
  onSearch, 
  searchQuery, 
  setSearchQuery, 
  onCountrySelect, 
  selectedCountry,
  onGenreSelect,
  selectedGenre,
  onShowTop10,
  onOpenCustomization,
  onOpenFavorites,
  favoritesCount = 0
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { t } = useTranslation()

  const handleSearch = (e) => {
    e.preventDefault()
    onSearch(searchQuery)
  }

  return (
    <header className="sticky top-0 z-50 glass-effect border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Radio className="h-8 w-8 text-primary" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold neon-text text-primary">{t('header.title')}</h1>
              <p className="text-xs text-muted-foreground">{t('header.subtitle')}</p>
            </div>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <form onSubmit={handleSearch} className="flex w-full">
              <Input
                type="text"
                placeholder={t('header.search.placeholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="rounded-r-none border-r-0"
              />
              <Button type="submit" className="rounded-l-none">
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-4">
            <CountryFilter 
              onCountrySelect={onCountrySelect}
              selectedCountry={selectedCountry}
            />
            <GenreFilter
              onGenreSelect={onGenreSelect}
              selectedGenre={selectedGenre}
            />
            <Button variant="ghost" onClick={onShowTop10}>
              {t('header.top10')}
            </Button>
            <Button variant="outline">{t('header.add_station')}</Button>
            
            {/* Favorites Button */}
            <Button 
              variant="ghost" 
              onClick={onOpenFavorites}
              className="relative"
            >
              <Star className="h-4 w-4" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </Button>
            
            {/* Customization Button */}
            <Button variant="ghost" onClick={onOpenCustomization}>
              <Settings className="h-4 w-4" />
            </Button>
            
            <LanguageSelector />
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-4">
          <form onSubmit={handleSearch} className="flex">
            <Input
              type="text"
              placeholder={t('header.search.placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="rounded-r-none border-r-0"
            />
            <Button type="submit" className="rounded-l-none">
              <Search className="h-4 w-4" />
            </Button>
          </form>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 space-y-2">
            <div className="flex flex-col space-y-2">
              <CountryFilter 
                onCountrySelect={onCountrySelect}
                selectedCountry={selectedCountry}
              />
              <GenreFilter
                onGenreSelect={onGenreSelect}
                selectedGenre={selectedGenre}
              />
            </div>
            <Button variant="ghost" className="w-full justify-start" onClick={onShowTop10}>
              {t('header.top10')}
            </Button>
            <Button variant="outline" className="w-full">{t('header.add_station')}</Button>
            
            <div className="flex space-x-2">
              <Button 
                variant="ghost" 
                className="flex-1 justify-start relative"
                onClick={onOpenFavorites}
              >
                <Star className="h-4 w-4 mr-2" />
                Favoritos
                {favoritesCount > 0 && (
                  <span className="ml-auto bg-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {favoritesCount}
                  </span>
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                className="flex-1 justify-start"
                onClick={onOpenCustomization}
              >
                <Settings className="h-4 w-4 mr-2" />
                Personalizar
              </Button>
            </div>
            
            <div className="flex justify-center pt-2">
              <LanguageSelector />
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Header

