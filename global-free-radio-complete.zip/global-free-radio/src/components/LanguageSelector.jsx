import { Languages } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { languageNames } from '../i18n/translations'
import { useTranslation } from '../hooks/useTranslation'

const LanguageSelector = () => {
  const { language, changeLanguage } = useTranslation()

  const getLanguageFlag = (lang) => {
    const flags = {
      pt: '🇧🇷',
      en: '🇺🇸',
      es: '🇪🇸',
      fr: '🇫🇷',
      de: '🇩🇪'
    }
    return flags[lang] || '🌍'
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="flex items-center space-x-2">
          <Languages className="h-4 w-4" />
          <span className="hidden sm:inline">{getLanguageFlag(language)}</span>
          <span className="hidden md:inline">{languageNames[language]}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {Object.entries(languageNames).map(([code, name]) => (
          <DropdownMenuItem
            key={code}
            onClick={() => changeLanguage(code)}
            className={language === code ? 'bg-accent' : ''}
          >
            <div className="flex items-center space-x-2">
              <span className="text-lg">{getLanguageFlag(code)}</span>
              <span>{name}</span>
              {language === code && (
                <span className="ml-auto text-xs text-primary">✓</span>
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export default LanguageSelector

