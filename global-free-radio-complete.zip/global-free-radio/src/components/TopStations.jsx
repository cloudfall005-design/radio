import { useState, useEffect } from 'react'
import { TrendingUp, Crown, Trophy, Medal } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import StationCard from './StationCard'

const TopStations = ({ onPlay, onPause, currentStation, isPlaying, favorites, onToggleFavorite }) => {
  const [topStations, setTopStations] = useState([])
  const [loading, setLoading] = useState(false)
  const [category, setCategory] = useState('clicks') // clicks, votes, recent

  useEffect(() => {
    loadTopStations()
  }, [category])

  const loadTopStations = async () => {
    setLoading(true)
    try {
      let endpoint = ''
      switch (category) {
        case 'clicks':
          endpoint = 'https://de1.api.radio-browser.info/json/stations/topclick/10'
          break
        case 'votes':
          endpoint = 'https://de1.api.radio-browser.info/json/stations/topvote/10'
          break
        case 'recent':
          endpoint = 'https://de1.api.radio-browser.info/json/stations/lastchange/10'
          break
        default:
          endpoint = 'https://de1.api.radio-browser.info/json/stations/topclick/10'
      }
      
      const response = await fetch(endpoint)
      const data = await response.json()
      setTopStations(data)
    } catch (error) {
      console.error('Error loading top stations:', error)
    } finally {
      setLoading(false)
    }
  }

  const isCurrentlyPlaying = (station) => {
    return currentStation?.stationuuid === station.stationuuid && isPlaying
  }

  const isFavorite = (station) => {
    return favorites.some(fav => fav.stationuuid === station.stationuuid)
  }

  const getCategoryIcon = () => {
    switch (category) {
      case 'clicks':
        return <TrendingUp className="h-5 w-5" />
      case 'votes':
        return <Crown className="h-5 w-5" />
      case 'recent':
        return <Medal className="h-5 w-5" />
      default:
        return <TrendingUp className="h-5 w-5" />
    }
  }

  const getCategoryTitle = () => {
    switch (category) {
      case 'clicks':
        return 'Mais Ouvidas'
      case 'votes':
        return 'Mais Votadas'
      case 'recent':
        return 'Recém Adicionadas'
      default:
        return 'Mais Ouvidas'
    }
  }

  const getRankIcon = (index) => {
    switch (index) {
      case 0:
        return <Trophy className="h-5 w-5 text-yellow-500" />
      case 1:
        return <Medal className="h-5 w-5 text-gray-400" />
      case 2:
        return <Medal className="h-5 w-5 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-muted-foreground">#{index + 1}</span>
    }
  }

  return (
    <Card className="glass-effect">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            {getCategoryIcon()}
            <span>Top 10 - {getCategoryTitle()}</span>
          </CardTitle>
          <div className="flex space-x-1">
            <Badge
              variant={category === 'clicks' ? 'default' : 'outline'}
              className="cursor-pointer"
              onClick={() => setCategory('clicks')}
            >
              Ouvidas
            </Badge>
            <Badge
              variant={category === 'votes' ? 'default' : 'outline'}
              className="cursor-pointer"
              onClick={() => setCategory('votes')}
            >
              Votadas
            </Badge>
            <Badge
              variant={category === 'recent' ? 'default' : 'outline'}
              className="cursor-pointer"
              onClick={() => setCategory('recent')}
            >
              Recentes
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">
            <div className="inline-flex items-center space-x-2">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
              <span>Carregando ranking...</span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {topStations.map((station, index) => (
              <div key={station.stationuuid} className="flex items-center space-x-3">
                <div className="flex-shrink-0 w-8 flex justify-center">
                  {getRankIcon(index)}
                </div>
                <div className="flex-1">
                  <StationCard
                    station={station}
                    isPlaying={isCurrentlyPlaying(station)}
                    onPlay={onPlay}
                    onPause={onPause}
                    isFavorite={isFavorite(station)}
                    onToggleFavorite={onToggleFavorite}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default TopStations

